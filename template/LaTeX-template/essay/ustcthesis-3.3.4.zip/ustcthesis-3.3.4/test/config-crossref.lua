testfiledir = "./test/testfiles-crossref"

checkruns = 2
