# Notes-LaTeX [⚠️ WIP]

This repository has a LaTeX template to take notes. The assets and sections files present are related to a course of "Group Theory."

Work in progress. I will update this readme file.
